# Rummikub > 2026-01-04 1:58am
https://universe.roboflow.com/rummikue/rummikub-nvypk-8cwem

Provided by a Roboflow user
License: CC BY 4.0

